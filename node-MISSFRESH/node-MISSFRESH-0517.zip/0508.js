//首页
{code: 0, is_chrome: 0, banner_bg_img: "", header_tip: {link_type: "app_download", image: "",…},…}
banner_bg_img:""
category_list:[,…]
code:0
default_category:"hb-newsy"
event:{group_purchase_hint: "赚80元"}
first_page_addr_text:"本城市支持会员1小时达，选择详细地址完成匹配"
header_tip:{link_type: "app_download", image: "",…}
img_url:"https://j-image.missfresh.cn/img_20161108170905880.png"
is_chrome:0
product_list:{
	banner: [{image: "https://j-image.missfresh.cn/img_20170627185311186.png", name: "优鲜严选",…},…],…}banner:[{path: "https://j-image.missfresh.cn/img_20180510000644953.jpg",…},…]
	brands:[{image: "https://j-image.missfresh.cn/img_20170627185311186.png", name: "优鲜严选",…},…]
	category_areas:[,…]
	is_vip:1
	member_level:1
	products:[{code: "hbdaojishi", group_img: null, backgroud_color: 0, enabled_banner: 1,…},…]
	show_lines:1
	station_code:""
	type:1
	wx_app_new_img:""


//首页--->category_list
category_list:[,…]
	0:{category_image: "https://j-image.missfresh.cn/img_20180511013332836.png", presell: 0, default: 1,…}
		category_image:"https://j-image.missfresh.cn/img_20180511013332836.png"
		category_tag:""
		category_type:"首页频道"
		default:1
		group:0
		group_bottom_img:""
		icon:"https://j-image.missfresh.cn/img_20180321171715156.jpg"
		internal_id:"hb-newsy"
		is_home:1
		name:"时尚扒虾节"
		ordering:2000
		presell:0
	1:{category_image: "https://j-image.missfresh.cn/img_20180424000836595.png", presell: 0, default: 0,…}
		category_image:"https://j-image.missfresh.cn/img_20180424000836595.png"
		category_tag:""
		category_type:""
		default:0
		group:0
		group_bottom_img:""
		icon:"https://j-image.missfresh.cn/img_20180424115241210.png"
		internal_id:"bj-vip"
		is_home:0
		name:"会员6折"
		ordering:1000
		presell:0


//首页--->product_list--->banner
banner:[{path: "https://j-image.missfresh.cn/img_20180510000644953.jpg",…},…]
	0:{path: "https://j-image.missfresh.cn/img_20180510000644953.jpg",…}
	height:525
	link:"https://as-vip.missfresh.cn/ug/active-page.html?promotionId=2717&address_code=110108&station_code=&warehouse_code=MRYXTJ&category_code=hb-newsy&is_vip=1&parent_banner_type=1&parent_banner_id=2144&app_version=&banner_name=page_%E7%88%86%E6%96%99%E9%BA%BB%E5%B0%8F+1000%E7%9B%92%E6%8A%A2%E9%B2%9C%E5%90%83"
	name:"爆料麻小 1000盒抢鲜吃"
	path:"https://j-image.missfresh.cn/img_20180510000644953.jpg"
	promotion_id:"2717"
	share_invite_content:{wx_share_type: 1, image_url: "https://j-image.missfresh.cn/img_20180510182007000.jpg",…}
	storage_money_status:"0"
	type:"WEBPROMOTION"
	width:1125


//首页--->product_list--->banner--->share_invite_content
share_invite_content:{wx_share_type: 0, image_url: "https://j-image.missfresh.cn/img_20180511021130943.jpg",…}
	content:"时尚扒虾节，满99送99，抢>>>"
	friend_share_type:0
	friend_url:"https://as-vip.missfresh.cn/ug/active-page.html?promotionId=50190&address_code=110108&station_code=&warehouse_code=MRYXTJ&category_code=hb-newsy&is_vip=1&parent_banner_type=1&parent_banner_id=2171&app_version=&banner_name=page_%E6%97%B6%E5%B0%9A%E6%89%92%E8%99%BE%E8%8A%82"
	image_url:"https://j-image.missfresh.cn/img_20180511021130943.jpg"
	qqFriendShareType:0
	qqFriendUrl:"https://as-vip.missfresh.cn/ug/active-page.html?promotionId=50190&address_code=110108&station_code=&warehouse_code=MRYXTJ&category_code=hb-newsy&is_vip=1&parent_banner_type=1&parent_banner_id=2171&app_version=&banner_name=page_%E6%97%B6%E5%B0%9A%E6%89%92%E8%99%BE%E8%8A%82"
	qr_info:{bg_i_url: "", qr_size: 70, qr_y: 419, qr_x: 80}
	sina_url:"https://as-vip.missfresh.cn/ug/active-page.html?promotionId=50190&address_code=110108&station_code=&warehouse_code=MRYXTJ&category_code=hb-newsy&is_vip=1&parent_banner_type=1&parent_banner_id=2171&app_version=&banner_name=page_%E6%97%B6%E5%B0%9A%E6%89%92%E8%99%BE%E8%8A%82"title:"1.5元一只的麻小快帮抢下，我扒虾呢，手上有油！"wx_share_type:0wx_url:"https://as-vip.missfresh.cn/ug/active-page.html?promotionId=50190&address_code=110108&station_code=&warehouse_code=MRYXTJ&category_code=hb-newsy&is_vip=1&parent_banner_type=1&parent_banner_id=2171&app_version=&banner_name=page_%E6%97%B6%E5%B0%9A%E6%89%92%E8%99%BE%E8%8A%82"


//首页--->product_list--->banner--->share_invite_content--->qr_info
qr_info:{bg_i_url: "", qr_size: 70, qr_y: 419, qr_x: 80}
	bg_i_url:""
	qr_size:70
	qr_x:80
	qr_y:419


//首页--->product_list--->brands
brands:[{image: "https://j-image.missfresh.cn/img_20170627185311186.png", name: "优鲜严选",…},…]
	0:{image: "https://j-image.missfresh.cn/img_20170627185311186.png", name: "优鲜严选",…}
		image:"https://j-image.missfresh.cn/img_20170627185311186.png"
		link:"https://as-vip.missfresh.cn/v1/h5model/strict-selection"
		name:"优鲜严选"
	1:{image: "https://j-image.missfresh.cn/img_20170627184654084.png", name: "安心检测",…}
		image:"https://j-image.missfresh.cn/img_20170627184654084.png"
		link:"https://as-vip.missfresh.cn/v1/h5model/safeguard"
		name:"安心检测"
	2:{image: "https://j-image.missfresh.cn/img_20170718194948016.png", name: "赔付保障",…}
		image:"https://j-image.missfresh.cn/img_20170718194948016.png"
		link:"https://p-h5.missfresh.cn/h5_file/467AA9256CCD5AB8F364815C073C00FD/index.html"
		name:"赔付保障"


//首页--->product_list--->category_areas
category_areas:[,…]
	0:{image: "https://j-image.missfresh.cn/img_20180511015339404.png", user_type: "NEWUSER", ordering: 4,…}
		id:6460
		image:"https://j-image.missfresh.cn/img_20180511015339404.png"
		name:"只属于你的特惠"
		ordering:4
		params:{image: "https://j-image.missfresh.cn/img_20180403101557574.jpg",…}
		placeholder:0
		type:"NEWUSER"
		user_type:"NEWUSER"


//首页--->product_list--->category_areas--->params
params:{image: "https://j-image.missfresh.cn/img_20180403101557574.jpg",…}
	bt_name:"新用户登录后就可获得大礼包哦"
	image:"https://j-image.missfresh.cn/img_20180403101557574.jpg"
	url:"https://as-vip.missfresh.cn/ug/new-enjoy.html?station_code=&address_code=110108"


//单个产品
{image: "http://missfresh-fms.ufile.ucloud.cn/9a4caa8c7a7c4caf938fd24997757a24.jpg",…}
buy_permission:0
cart_btn_name:"加入购物车"
cart_image:"https://j-image.missfresh.cn/img_20170425134548759.png"
image:"http://missfresh-fms.ufile.ucloud.cn/9a4caa8c7a7c4caf938fd24997757a24.jpg"
name:"爆料麻辣小龙虾（4-6钱）500g"
nationwide:0
pao:0
product_tags:[{name: "红包不可用",…}]
promoteLevel:0
promote_tag:"https://j-image.missfresh.cn/img_20170605114049455.png"
promote_tag_new:""
seckill_limit:0
sell_out:false
sku:"p-blmlxlx4-6-500g"
stock:1016
subtitle:"我的3秒剥虾功就这么练出来"
supplier:null
type:"product"
vip_price_pro:{price_up: {name: "", show_type: 2, color: 9868950, price: 5990},…}
vip_product:0


//单个产品--->product_tags
product_tags:[{name: "红包不可用",…}]
	0:{name: "红包不可用",…}
	color:16097217
	icon:"https://image.missfresh.cn/category_tag_images/64C7BDFCE3063869F16B409A2851887D.PNG"
	name:"红包不可用"
	type:"property"

//单个产品--->vip_price_pro
vip_price_pro:{price_up: {name: "", show_type: 2, color: 9868950, price: 1690},…}
	price_down:{name: "", show_type: 1, color: 16730257, price: 1290}
		color:16730257
		name:""
		price:1290
		show_type:1
	price_up:{name: "", show_type: 2, color: 9868950, price: 1690}
		color:9868950
		name:""
		price:1690
		show_type:2






//点击购物车
https:\\as-vip.missfresh.cn/v1/cart/add?
	device_id=2eb26f8561925a51300844f37f8720db&
	env=web&
	platform=web&
	uuid=2eb26f8561925a51300844f37f8720db&
	access_token=THBMZmhybkgyNlNBRlNTWTFPV084ZDBJUXVBUy9JemFvb0ZhQ1hDcml5ND0%3D&
	version=4.3.0.2&
	fromSource=zhuye&
	screen_height=320&
	screen_width=568
