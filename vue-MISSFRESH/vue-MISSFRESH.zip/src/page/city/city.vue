<template>
	<div>
		hello world!
	</div>
</template>
<script>
	export default{
		data(){
			return {

			}
		}
	}
</script>
<style>
	
</style>