<template>
	<div>
		<foot-guide></foot-guide>
	</div>
</template>
<script>
	import footGuide from 'src/components/footer/footGuide'
	export default{
		data(){
			return {

			}
		},
		components:{
	        footGuide
	    },
	}
</script>
<style>
	
</style>